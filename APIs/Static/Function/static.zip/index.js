exports.handler = async (event) => {
    const response = {
        data:[{
                "message":"This is Data returned from you API!"
            }
        ]
    };
return response;
};
